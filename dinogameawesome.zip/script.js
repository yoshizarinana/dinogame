const character = document.getElementById("character");
const block = document.getElementById("block");
const scoreText = document.getElementById("score");

let score = 0;
let gameRunning = true;

function jump() {
    if (character.classList.contains("animate")) {
        return;
    }

    character.classList.add("animate");

    setTimeout(() => {
        character.classList.remove("animate");
    }, 500);
}

// Score system
// Every cactus passed = 500 points
setInterval(() => {
    if (!gameRunning) return;

    const blockLeft = parseInt(
        window.getComputedStyle(block).getPropertyValue("left")
    );

    if (blockLeft < 5 && blockLeft > -5) {
        score += 500;
        scoreText.innerHTML = score;
    }
}, 50);

// Collision detection
const checkDead = setInterval(() => {
    const characterBottom = parseInt(
        window.getComputedStyle(character).getPropertyValue("bottom")
    );

    const blockLeft = parseInt(
        window.getComputedStyle(block).getPropertyValue("left")
    );

    if (blockLeft < 90 && blockLeft > 40 && characterBottom < 40) {
        block.style.animation = "none";
        block.style.display = "none";

        gameRunning = false;

        alert("Game Over! Final Score: " + score);
    }
}, 10);
